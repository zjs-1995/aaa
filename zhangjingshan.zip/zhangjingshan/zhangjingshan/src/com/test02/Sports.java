package com.test02;

public interface Sports {
    void swimming ();
}
